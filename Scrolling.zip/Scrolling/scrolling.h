#ifndef SCROLLING_H_
#define SCROLLING_H_
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
typedef struct scrolling
{
SDL_Surface *background;
SDL_Rect posBack;
}scroll;
void initialiser(scroll *s);
void afficher (scroll *s,SDL_Surface *ecran);
void scrolling(scroll *s,SDL_Surface *ecran);
#endif /* SCROLLING_H_ */

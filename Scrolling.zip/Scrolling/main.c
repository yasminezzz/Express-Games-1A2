#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "scrolling.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char *argv[])
{
SDL_Surface *Screen = NULL;
scroll s;
SDL_Init(SDL_INIT_VIDEO);
    Screen = SDL_SetVideoMode(800, 680, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Ma super fenêtre SDL !", NULL);
SDL_FillRect(Screen, NULL, SDL_MapRGB(Screen->format, 255, 255, 255));
initialiser(&s);
afficher(&s,Screen);
SDL_Flip(Screen);

int continuer=1;
SDL_Event event;
while(continuer)
{
SDL_PollEvent(&event);
switch(event.type)
{
case SDL_KEYDOWN:
scrolling(&s,Screen);
break;
case SDL_QUIT:
continuer=0;
}
}
free(s.background);
SDL_Quit();
}

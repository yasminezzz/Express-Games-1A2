#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scrolling.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
void initialiser(scroll *s)
{
s->background = IMG_Load("background.png");
s->posBack.x=0;
s->posBack.y=0;
s->posBack.w=500;
s->posBack.h=680;
}
void afficher(scroll *s,SDL_Surface *ecran)
{
SDL_BlitSurface(s->background, NULL, ecran,&s->posBack);
}
void scrolling(scroll *s,SDL_Surface *ecran)
{
Uint8 *keystates = SDL_GetKeyState(NULL );
SDL_Event event;
SDL_PollEvent(&event);

if(keystates[SDLK_RIGHT])
{
s->posBack.x=s->posBack.x-20;
SDL_BlitSurface(s->background,&s->posBack, ecran,NULL);
SDL_Flip(ecran);
}
if(keystates[SDLK_LEFT])
{
s->posBack.x=s->posBack.x+20;
SDL_BlitSurface(s->background, &s->posBack, ecran,NULL);
SDL_Flip(ecran);
}
}
